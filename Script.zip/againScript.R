setwd("./Coursera-SwiftKey/final/en_US")

UStwitConn <- file("en_US.twitter.txt","r")
twitTxt <- readLines(UStwitConn, skipNul = TRUE, encoding = "UTF-8")
close(UStwitConn)

USblogConn <- file("en_US.blogs.txt","r")
blogTxt <- readLines(USblogConn, skipNul = TRUE, encoding = "UTF-8")
close(USblogConn)

USnewsConn <- file("en_US.news.txt","r")
newsTxt <- readLines(USnewsConn, skipNul = TRUE, encoding = "UTF-8")
close(USnewsConn)

#Sample
set.seed(930908)
twitSam <- twitTxt[sample(length(twitTxt), length(twitTxt) / 4)]
blogSam <- blogTxt[sample(length(blogTxt), length(blogTxt) / 4)]
newsSam <- newsTxt[sample(length(newsTxt), length(newsTxt) / 4)]

library(dplyr)
twitSam <- data_frame(text = twitSam)
blogSam <- data_frame(text = blogSam)
newsSam <- data_frame(text = newsSam)
DF <- bind_rows(twitSam, blogSam, newsSam) %>% mutate(num = row_number())

setwd("C:/Users/hbkim/Desktop/coursera/Capstone")
save(DF, file = "DF.RData")

set.seed(930908)
index <- sample(1:nrow(DF), nrow(DF)*0.75)
train <- DF[index,]
test <- DF[-index,]

##Minize size?
#object.size()

library(tidytext)
data("stop_words")
Word <- train %>% unnest_tokens(word, text) %>%
    anti_join(stop_words)
Wordcount <- Word %>% count(word, sort = TRUE)

rebind <- Word %>% group_by(num) %>% summarise(text = paste(word, collapse = " "))

save(rebind, file = "rebind.RData")
save(Wordcount, file = "Word.RData")
#Bigram
Bigram <- rebind %>% unnest_tokens(bigram, text, token = "ngrams", n = 2) %>%
    count(bigram, sort = TRUE) %>% mutate(bigram = reorder(bigram, n))

#Trigram
Trigram <- rebind %>% unnest_tokens(trigram, text, token = "ngrams", n = 3) %>%
    count(trigram, sort = TRUE) %>% mutate(trigram = reorder(trigram, n))

#four-gram
Fourgram <- rebind %>% unnest_tokens(fourgram, text, token = "ngrams", n = 4) %>%
    count(fourgram, sort = TRUE) %>% mutate(fourgram = reorder(fourgram, n))

###############################################################################33
save(Bigram, Trigram, Fourgram, file = "ngram1.RData")
library(tidyr)

BigramP <- Bigram %>% separate(bigram, c("word1","word2"), sep = " ") %>% filter(!is.na(word1))
TrigramP <- Trigram %>% separate(trigram, c("word1","word2","word3"), sep = " ") %>%
    filter(!is.na(word1))
FourgramP <- Fourgram %>% separate(fourgram, c("word1","word2","word3", "word4"), sep = " ") %>%
    filter(!is.na(word1))
#remove n = 1..
BigramP <- BigramP %>% filter(n > 1)
TrigramP <- TrigramP %>% filter(n > 1)
FourgramP <- FourgramP %>% filter(n > 1)

save(BigramP, TrigramP, FourgramP, file = "ngramP.RData")

#ngram model
model <- function(sentence){
    df <- data_frame(text = sentence)
    df <- df %>% unnest_tokens(word, text) %>% anti_join(stop_words)
    char1 <- tail(df,3)$word[1]
    char2 <- tail(df,3)$word[2]
    char3 <- tail(df,3)$word[3]
    check1 <- FourgramP %>% filter(word1 == char1) %>%
        filter(word2 == char2) %>%
        filter(word3 == char3)
    check2 <- TrigramP %>% filter(word1 == char2) %>%
        filter(word2 == char3)
    check3 <- BigramP %>% filter(word1 == char3)
    if(nrow(check1) > 0){
        print(check1[1,4])
    } else if(nrow(check2) > 0){
        print(check2[1,3])
    } else if(nrow(check3) > 0){
        print(check3[1,2])
    } else {
        print("Cannot predict")
    }
}

#file.size("ngramP.RData)

#Making back off model
