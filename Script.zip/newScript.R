library(dplyr)
library(tidytext)
library(tidyr)

setwd("./Coursera-SwiftKey/final/en_US")

UStwitConn <- file("en_US.twitter.txt","r")
twitTxt <- readLines(UStwitConn, skipNul = TRUE, encoding = "UTF-8")
close(UStwitConn)

USblogConn <- file("en_US.blogs.txt","r")
blogTxt <- readLines(USblogConn, skipNul = TRUE, encoding = "UTF-8")
close(USblogConn)

USnewsConn <- file("en_US.news.txt","r")
newsTxt <- readLines(USnewsConn, skipNul = TRUE, encoding = "UTF-8")
close(USnewsConn)

setwd("C:/Users/hbkim/Desktop/coursera/Capstone")
#Sample
set.seed(930908)
twitSam <- twitTxt[sample(length(twitTxt), length(twitTxt) / 4)]
blogSam <- blogTxt[sample(length(blogTxt), length(blogTxt) / 4)]
newsSam <- newsTxt[sample(length(newsTxt), length(newsTxt) / 4)]

twitSam <- data_frame(text = twitSam)
blogSam <- data_frame(text = blogSam)
newsSam <- data_frame(text = newsSam)
DF <- bind_rows(twitSam, blogSam, newsSam) %>% mutate(num = row_number())

save(DF, file = "DF_raw.RData")

set.seed(930908)
index <- sample(1:nrow(DF), nrow(DF)*0.75)
train <- DF[index,]
test <- DF[-index,]

##Minimize size??
#object.size(train)

Word <- train %>% unnest_tokens(word, text) %>% count(word, sort = TRUE) %>%
    mutate(word = reorder(word, n))

#Bigram
Bigram <- train %>% unnest_tokens(bigram, text, token = "ngrams", n = 2) %>%
    count(bigram, sort = TRUE) %>% mutate(bigram = reorder(bigram, n))

#Trigram
Trigram <- train %>% unnest_tokens(trigram, text, token = "ngrams", n = 3) %>%
    count(trigram, sort = TRUE) %>% mutate(trigram = reorder(trigram, n))

#four-gram
Fourgram <- train %>% unnest_tokens(fourgram, text, token = "ngrams", n = 4) %>%
    count(fourgram, sort = TRUE) %>% mutate(fourgram = reorder(fourgram, n))

save(Word, Bigram, Trigram, Fourgram, file = "ngram_raw.RData")
###############################################################################33

BigramP <- Bigram %>% separate(bigram, c("word1","word2"), sep = " ")
TrigramP <- Trigram %>% separate(trigram, c("word1","word2","word3"), sep = " ")
FourgramP <- Fourgram %>% separate(fourgram, c("word1","word2","word3", "word4"), sep = " ")

BigramP <- BigramP %>% filter(n > 1)
TrigramP <- TrigramP %>% filter(n > 1)
FourgramP <- FourgramP %>% filter(n > 1)

Bigram_raw <- BigramP %>% filter(!is.na(word1))
Trigram_raw <- TrigramP %>% filter(!is.na(word1))
Fourgram_raw <- FourgramP %>% filter(!is.na(word1))

save(Word, Bigram_raw, Trigram_raw, Fourgram_raw, file = "ngramP_raw.RData")

model <- function(char1, char2, char3){
    check1 <- FourgramP %>% filter(word1 == char1) %>%
        filter(word2 == char2) %>%
        filter(word3 == char3)
    check2 <- TrigramP %>% filter(word1 == char2) %>%
        filter(word2 == char3)
    check3 <- BigramP %>% filter(word1 == char3)
    if(nrow(check1) > 0){
        print(check1[1,4])
    } else if(nrow(check2) > 0){
        print(check2[1,3])
    } else if(nrow(check3) > 0){
        print(check3[1,2])
    } else {
        print("Cannot predict")
    }
}
